import "./mac-book-pro162.css";

const MacBookPro162 = () => {
  return (
    <div className="macbook-pro-16-2">
      <div className="navbar-div">
        <div className="nav-div">
          <a className="home-a">Home</a>
          <div className="learn-div">Learn</div>
          <div className="learn-div">Projects</div>
          <div className="learn-div">Code</div>
        </div>
        <img
          className="logo-social-1-icon"
          alt=""
          src="../logosocial-1@2x.png"
        />
      </div>
      <div className="hero-div">
        <b className="programming-made-easy-learn-to">
          <p className="programming-made-easy">Programming Made Easy</p>
          <p className="learn-to-code">Learn To Code Online.</p>
        </b>
        <img className="thumb-1-icon" alt="" src="../thumb-1@2x.png" />
        <div className="rectangle-div" />
        <button className="rectangle-button" />
        <div className="learn-programming-free-creat">
          <p className="programming-made-easy">{`Learn Programming Free &  Create New Softwares.`}</p>
          <p className="learn-to-code">
            Skill is a Art Acquired By Proffesionals
          </p>
        </div>
        <b className="enroll-now-b">ENROLL NOW</b>
        <b className="courses-b">COURSES</b>
      </div>
    </div>
  );
};

export default MacBookPro162;
